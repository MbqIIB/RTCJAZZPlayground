package com.ibm.team.filesystem.cli.client;

public abstract class AbstractSubcommand
  extends com.ibm.team.filesystem.cli.core.AbstractSubcommand
{
  public AbstractSubcommand() {}
}
