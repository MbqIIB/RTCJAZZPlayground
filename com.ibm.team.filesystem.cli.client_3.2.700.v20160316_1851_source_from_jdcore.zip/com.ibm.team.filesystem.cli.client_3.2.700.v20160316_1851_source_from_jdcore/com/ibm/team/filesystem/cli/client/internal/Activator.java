package com.ibm.team.filesystem.cli.client.internal;

import org.eclipse.core.runtime.Plugin;
import org.osgi.framework.BundleContext;






public class Activator
  extends Plugin
{
  public static final String PLUGIN_ID = "com.ibm.team.filesystem.cli.client";
  
  public Activator() {}
  
  public void start(BundleContext context)
    throws Exception
  {
    super.start(context);
  }
}
